<template>
  <div>
    <CreateComForm />
  </div>
</template>

<script setup lang="ts">
import CreateComForm from '@/components/com/CreateComForm.vue';
</script>

<style scoped>
/* Estilos para la vista si son necesarios */
</style> 